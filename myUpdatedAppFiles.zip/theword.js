'use strict';

module.exports = (theWord) => {
  console.log("and nobody cares");
};
