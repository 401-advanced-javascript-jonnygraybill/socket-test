'use strict';

const theword = require('./theword.js');

const io = require('socket.io-client');

const socket = io.connect('https://socket-test-1.scm.azurewebsites.net/');

socket.on('the-bird', theword);

